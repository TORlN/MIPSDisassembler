#ifndef HELPERS_2_H
#define HELPERS_2_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>

// Declare any helper functions here
int stringLength(char * str);
int isBlank(char c);
int verifyHex(char * line);
int verifyMneumonic(char * str);
int verifyPetty(char * str);
uint32_t charToHex(char * str);
uint8_t strint8(const char* str);
#endif

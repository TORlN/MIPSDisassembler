#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "hw2.h"
#include "hw2_helpers.h"


#define USAGE_MSG   "53MIPSD [-H] [-O ofile] [-I INFILE] [-N] IMAPFILE\n" \
                    "\n  -H    Prints the usage statement to STDOUT. All other arguments are ignored."  \
                    "\n  -O    OUTFILE Results are printed into the OUTFILE specified instead of STDOUT."  \
                    "\n  -I    INFILE Inputs are read from the INFILE specified instead of STDIN." \
                    "\n  -N    Prints the registers as numerical values, instead of human-readable names\n" \

int main(int argc, char* argv[]) {

    char* OUTFILE = NULL; // The output file (remains NULL if -O option is not provided) 
    char* INFILE = NULL; // The input file (remains NULL if -I option is not provided)
    int NUMERIC = 0; // Numeric mode (remains false if -N option is not provided)
    opterr = 0;
    int c;
    while ((c = getopt(argc, argv, "HO:I:N")) >= 0) {
        switch (c){
        case 'H':
            printf(USAGE_MSG);
            return EXIT_SUCCESS;
        case 'O':
            OUTFILE = optarg;
            break;
        case 'I':
            INFILE = optarg;
            break;
        case 'N':
            NUMERIC = 1;
            break;
        case '?':
            if (optopt == 'i' || optopt == 'o') {
                fprintf(stderr, "Option -%c requires an argument.\n\n" USAGE_MSG, optopt);
            }
        default:
            fprintf(stderr, USAGE_MSG);
            return EXIT_FAILURE;
        }
    }

    // validate that we only have 1 positional argument
    if (optind + 1 != argc) {
        fprintf(stderr, "Exactly one positional argument should be specified.\n\n" USAGE_MSG);
        return EXIT_FAILURE;
    }

    char* imapfile = argv[optind]; // The IMAPFILE specified

    // INFILE, ofile, numeric and imapfile are now usable by your program!
    // THE PRINT STATEMENTS BELOW ARE FOR DEBUGGING PURPOSES ONLY! Comment out from final implemenation
    // printf("INFILE: %s\n", INFILE);
    // printf("OUTFILE: %s\n", OUTFILE);
    // printf("NUMERIC: %d\n", NUMERIC);
    // printf("IMAPFILE: %s\n", imapfile);
    // THE PRINT STATEMENTS ABOVE ARE FOR DEBUGGING PURPOSES ONLY! Comment out from final implemenation

    // Create space for 1D array for the register names - still need to initialize!

 
    char* humanRegisters = "$zero,$at,$v0,$v1,$a0,$a1,$a2,$a3,$t0,$t1,$t2,$t3,$t4,$t5,$t6,$t7,$s0,$s1,$s2,$s3,$s4,$s5,$s6,$s7,$t8,$t9,$k0,$k1,$gp,$sp,$fp,$ra";
    char* numericRegisters = "$0,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31";
    int sizeHR = stringLength(humanRegisters);
    int sizeNR = stringLength(numericRegisters);
    char** regNames  = malloc(32*sizeof(char*));     
    // INSERT YOUR IMPLEMENTATION HERE

    FILE *FILEIN = stdin;
    FILE *FILEOUT = stdout;
    char * dynArr;
    int size = 0;
    if(NUMERIC == 0){
        dynArr = malloc((sizeHR+1)*sizeof(char));
        for(int i=0;i<=sizeHR;i++){
            *(dynArr+i) = *(humanRegisters+i);
        }
        size = getSubstrings(dynArr, ',', regNames, 32);
    }else{
        dynArr = malloc((sizeNR+1)*sizeof(char));
        for(int i=0;i<=sizeNR;i++){
            *(dynArr+i) = *(numericRegisters+i);
        }
        size = getSubstrings(dynArr, ',', regNames, 32);
    }
    if(INFILE != NULL){
        FILEIN = fopen(INFILE, "rb");
        if(FILEIN == NULL){
            free(dynArr);
            free(regNames); 
            return 2;
        }
    }
    if(OUTFILE != NULL){
        FILEOUT = fopen(OUTFILE, "w");
        if(FILEOUT == NULL){
            free(dynArr);
            free(regNames); 
            return 2;
        }
    }
    FILE *fmap = fopen(imapfile, "r");
    if(fmap == NULL){
        free(dynArr);
        free(regNames); 
        return 3;
    }

    list_t * theList = createMIPSinstrList(fmap);
    if(theList == NULL){
        free(dynArr);
        free(regNames); 
        DestroyList(&theList);
        return 3;
    }
    char * buffer = malloc(4*sizeof(char));
    size_t bytesRead = 0;
    int posBefore = 0;
    int posAfter = 0;
    while(!feof(FILEIN) && !ferror(FILEIN)){
        posBefore = ftell(FILEIN);
        size_t read = fread(buffer, 4, 1, FILEIN);
        posAfter = ftell(FILEIN);
        if(posBefore == posAfter){
            break;
        }else if(posAfter - posBefore != 4){
            free(buffer);
            DestroyList(&theList);
            free(dynArr);
            free(regNames);
            return 3;
        }
        uint32_t * value = (uint32_t *)buffer;
        MIPSfields * f = malloc(sizeof(MIPSfields));
        parseMIPSfields(*value, f);
        if(printInstr(f, theList, regNames, FILEOUT) == 0){
            free(buffer);
            DestroyList(&theList);
            free(dynArr);
            free(regNames);
            free(f);
            return 3;
        }
        free(f);
    }
    free(buffer);
    if(FILEIN!=NULL){
        fclose(FILEIN);
    }
    if(FILEOUT!=NULL){
        fclose(FILEOUT);
    }
    fclose(fmap);
    DestroyList(&theList);
    free(dynArr);
    free(regNames);  // free the memory we allocated because we are awesomely efficient programmers! 
    

    return EXIT_SUCCESS;
}

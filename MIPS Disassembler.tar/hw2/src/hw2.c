#include "linkedlist.h"
#include "hw2_helpers.h"
#include "hw2.h"

// Part 1 Functions
int getSubstrings(char *str,  char delim, char ** array, int maxSize) {
    if(str == NULL){
        return -1;
    }
    if(array == NULL){
        return -1;
    }
    if(maxSize < 1){
        return -1;
    }
    if(stringLength(str) == 0){
        return 0;
    }
    if(delim == '\0'){
        return 0;
    }
    int count = 0;
    int arrayIndex = 0;
    int stringSize = stringLength(str);
    for(int i=0;*(str+i) != '\0';i++){
        if(*(str+i) == delim){
            if(arrayIndex < maxSize){
                *(str+i) = '\0';
            }else{
                return count;
            }
            if(i > 0){
                for(int e=i-1;e>=0;e--){
                    if(*(str+e) == '\0'){
                        if(arrayIndex < maxSize){
                            *(array+arrayIndex) = str+(e+1);
                            arrayIndex++;
                            count++;
                            if(count == maxSize){
                                return count;
                            }else if(i == stringSize-1){
                                *(array+arrayIndex) = str+(i+1);
                                count++;
                            }
                            break;
                        }
                    }else if(e==0){
                        if(arrayIndex < maxSize){
                            *(array+arrayIndex) = str+e;
                            arrayIndex++;
                            count++;
                            if(count == maxSize){
                                return count;
                            }else if(i == stringSize-1){
                                *(array+arrayIndex) = str+(i+1);
                                count++;
                            }
                            break;
                        }
                    }
                }
            }
        }else if(*(str+(i+1)) == '\0'){
            for(int e=i-1;e>=0;e--){
                if(*(str+e) == '\0'){
                    if(arrayIndex < maxSize){
                        *(array+arrayIndex) = str+(e+1);
                        arrayIndex++;
                        count++;
                        if(count == maxSize){
                            return count;
                        }
                        break;
                    }
                }else if(e==0){
                    if(arrayIndex < maxSize){
                        *(array+arrayIndex) = str+e;
                        arrayIndex++;
                        count++;
                        if(count == maxSize){
                            return count;
                        }
                        break;
                    }
                }
            }
        }
    }
    return count;
}

void parseMIPSfields(const uint32_t instruction, MIPSfields* f) {
    f->opcode = (instruction >> 26) & 0x3F;
    f->rs = (instruction >> 21) & 0x1F;
    f->rt = (instruction >> 16) & 0x1F;
    f->rd = (instruction >> 11) & 0x1F;
    f->shamt = (instruction >> 6) & 0x1F;
    f->func = instruction & 0x3F;
    f->immediate16 = instruction & 0xFFFF;
    f->immediate26 = instruction & 0x3FFFFFF;
    if(f->opcode == 0x0){
        f->uid = f->func;
    }else{
        f->uid = (instruction >> 26) & 0xFF;
        f->uid = f->uid << 26;
    }
}

MIPSinstr* loadInstrFormat(char* line) {
    if (line == NULL) {
        return NULL;
    }

    MIPSinstr* s = malloc(sizeof(MIPSinstr));
    s->usagecnt = 0;

    int size = stringLength(line);
    char* str = malloc((size + 1) * sizeof(char));
    for (int i = 0; i <= size; i++) {
        *(str + i) = *(line + i);
    }
    
    char** strArray = malloc((size + 1) * sizeof(char*));

    int subStringSize = getSubstrings(str, ' ', strArray, 5);
    if (subStringSize != 4) {
        free(str);
        free(strArray);
        free(s);
        return NULL;
    }

    for (int i = 0; i < 4; i++) {
        char* p = *(strArray + i);
        if (i == 0) {
            if (*(line + i) == 'r' || *(line + i) == 'i' || *(line + i) == 'j') {
                s->type = *(p);
            } else {
                free(str);
                free(strArray);
                free(s);
                return NULL;
            }
        } else if (i == 1) {
            int counter = verifyHex(p);
            if (counter == -1) {
                free(str);
                free(strArray);
                free(s);
                return NULL;
            }
            uint32_t theHex = charToHex(p);
            s->uid = theHex;
        } else if (i == 2) {
            int counter = verifyMneumonic(p);
            if (counter == -1) {
                free(str);
                free(strArray);
                free(s);
                return NULL;
            }
            int mnemonicLength = stringLength(p);
            s->mnemonic = malloc((mnemonicLength+1) * sizeof(char));
            for(int j=0;j<mnemonicLength;j++){
                *(s->mnemonic+j) = *(p+j);
            }
            *(s->mnemonic+mnemonicLength) = '\0';
        } else if (i == 3) {
            int counter = verifyPetty(p);
            if (counter == -1) {
                free(str);
                free(strArray);
                free(s);
                return NULL;
            }
            *(p + counter) = '\0';
            uint8_t theInt = strint8(p);
            s->pretty = theInt;
        }
    }

    free(str);
    free(strArray);
    return s;
}


// Part 2 Functions
int MIPSinstr_uidComparator(const void* s1, const void* s2) {
    const MIPSinstr* mips1 = (const MIPSinstr*) s1;
    const MIPSinstr* mips2 = (const MIPSinstr*) s2;
    if(mips1->uid < mips2->uid){
        return-1;
    }else if(mips1->uid == mips2->uid){
        return 0;
    }else{
        return 1;
    }
}

void MIPSinstr_Printer(void* data, void* fp) {
    MIPSinstr * theData = (MIPSinstr*) data;
    FILE * FP = (FILE*) fp;
    fprintf(fp, "%c\t%u\t%u\t%u\t%s\n", theData->type, theData->uid, theData->pretty,
    theData->usagecnt, theData->mnemonic);
}

void MIPSinstr_Deleter(void* data) {
    if(data != NULL){
        MIPSinstr * theData = (MIPSinstr*) data;
        free(theData->mnemonic);
        free(theData);
    }
}

node_t* FindInList(list_t* list, void* token) {
    if(list == NULL){
        return NULL;
    }
    node_t* current = list->head;
    while(current != NULL){
        if(list->comparator(current->data, token) == 0){
            return current;
        }
        current = current->next;
    }
    return NULL;
}

void DestroyList(list_t** list)  {
    if(list != NULL && *list != NULL){
        node_t* current = (*list)->head;
        while(current != NULL){
            if((*list)->deleter != NULL){
                (*list)->deleter(current->data);
            }
            node_t* temp = current;
            current = current->next;
            free(temp);
        }
        free(*list);
        *list = NULL;
    }
}

// Part 3 Functions
list_t* createMIPSinstrList(FILE* IMAPFILE) {
    list_t * list = CreateList(&MIPSinstr_uidComparator, &MIPSinstr_Printer, &MIPSinstr_Deleter);

    unsigned BUFFER_SIZE = 1024;
    char * buffer = malloc(BUFFER_SIZE * sizeof(char));
    while(fgets(buffer, BUFFER_SIZE, IMAPFILE) != NULL){

        node_t * node = malloc(sizeof(node_t));
        MIPSinstr * instr = loadInstrFormat(buffer);
        if(instr == NULL){
            free(node);
            DestroyList(&list);
            break;
        }
        node->data = instr;
        InsertAtHead(list, node->data);
        free(node);
        
    }
    free(buffer);
    return list;
}

int printInstr(MIPSfields* instr, list_t* MIPSinstrList, char** regNames, FILE* OUTFILE) {
    if(instr == NULL){
        return 0;
    }
    if(MIPSinstrList == NULL){
        return 0;
    }
    if(regNames == NULL|| *regNames == NULL){
        return 0;
    }
    if(OUTFILE == NULL){
        return 0;
    }
    MIPSinstr theInstr;
    theInstr.uid = instr->uid;
    node_t* theNode = FindInList(MIPSinstrList, &theInstr);
    if(theNode == NULL){
        return 0;
    }
    MIPSinstr * data = (MIPSinstr*) theNode->data;
    data->usagecnt++;
    switch(data->pretty){
        case 0:
            fprintf(OUTFILE, "%s %s\n", data->mnemonic, *(regNames+instr->rd));
            break;
        case 1:
            fprintf(OUTFILE, "%s %s, %s\n", data->mnemonic, *(regNames+instr->rs), 
            *(regNames+instr->rt));
            break;
        case 2:
            fprintf(OUTFILE, "%s %s, %s, 0x%X\n", data->mnemonic, *(regNames+instr->rt),
            *(regNames+instr->rs), instr->immediate16);
            break;
        case 3:
            fprintf(OUTFILE, "%s %s, %s, %s\n", data->mnemonic, 
            *(regNames+instr->rd), *(regNames+instr->rs), *(regNames+instr->rt));
            break;
        case 4:
            fprintf(OUTFILE, "%s %s, 0x%X(%s)\n", data->mnemonic, 
            *(regNames+instr->rt), instr->immediate16, *(regNames+instr->rs));
            break;
        case 5:
            fprintf(OUTFILE, "%s\n", data->mnemonic);
            break;
        case 6:
            fprintf(OUTFILE, "%s 0x%X\n", data->mnemonic, instr->immediate26);
            break;
        case 7:
            fprintf(OUTFILE, "%s %s, 0x%X\n", data->mnemonic, *(regNames+instr->rs), 
            instr->immediate16);
            break;
        case 8:
            fprintf(OUTFILE, "%s %s, %s, 0x%X\n", data->mnemonic, *(regNames+instr->rd), 
            *(regNames+instr->rs), instr->shamt);
            break;
        case 9:
            fprintf(OUTFILE, "%s %s, %s, 0x%X\n", data->mnemonic, *(regNames+instr->rs), 
            *(regNames+instr->rt), instr->immediate16);
            break;
        case 10:
            fprintf(OUTFILE, "%s %s, 0x%X\n", data->mnemonic, *(regNames+instr->rt), 
            instr->immediate16);
            break;
        default:
            return 0;
    };
    return 1;
}


// Extra Credit Functions
void MIPSinstr_removeZeros(list_t* list) {
    if(list == NULL){
        return;
    }
    node_t * current = list->head;
    node_t * previous = list->head;
    while(current != NULL){
        MIPSinstr * data = current->data;
        if(data->usagecnt == 0){
            if(current == list->head){
                list->head = list->head->next;
                previous = list->head;
                list->length--;
                free(data->mnemonic);
                free(data);
                free(current);
                current = list->head;
            }else{
                previous->next = current->next;
                list->length--;
                free(data->mnemonic);
                free(data);
                node_t* temp = current;
                free(temp);
                current = previous->next;
            }
        }else{
            previous = current;
            current = current->next;
        }
    }
}

int MIPSinstr_usagecntComparator(const void* s1, const void* s2) {
    MIPSinstr* data1 = (MIPSinstr*) s1;
    MIPSinstr* data2 = (MIPSinstr*) s2;
    if(data1->usagecnt > data2->usagecnt){
        return -1;
    }else if(data1->usagecnt < data2->usagecnt){
        return 1;
    }else{
        if(data1->mnemonic < data2->mnemonic){
            return 1;
        }else{
            return -1;
        }
    }
}

void MIPSinstr_statPrinter(void* data, void* fp) {
    FILE *f = (FILE*) fp;
    node_t* theNode = (node_t*) data;
    MIPSinstr* theData = (MIPSinstr*) theNode->data;
    fprintf(f, "%s\t%u\n", theData->mnemonic, theData->usagecnt);
}

void sortLinkedList(list_t* list) {
    if(list==NULL || list->head == NULL || list->head->next == NULL){
        return;
    }

    node_t * sortedList = NULL;
    node_t * current = list->head;

    while(current != NULL){
        node_t* next = current->next;
        if(sortedList == NULL || list->comparator(sortedList->data, current->data) == -1){
            current->next = sortedList;
            sortedList = current;
        }else{
            node_t * temp = sortedList;
            while(temp->next != NULL && 
            list->comparator(temp->next->data, current->data) == 1){
                temp = temp->next;
            }
            current->next = temp->next;
            temp->next = current;
        }
        current = next;
    }
    list->head = sortedList;
}


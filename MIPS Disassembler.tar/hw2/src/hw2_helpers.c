#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>

// Define any helper functions here
int stringLength(char * str){
    int count = 0;
    for(int i=0;*(str+i) != '\0';i++){
        count++;
    }
    return count;
}

int isBlank(char c){
    if (c == ' ' || c == '\n' || c == '\0' || c == '\t' || c == '\r' || c == '\v' || c == '\f'){
        return 1;
    }else{
        return 0;
    }
}
// returns number of hex in string, if string is invalid hex return -1
int verifyHex(char *line){
    int counter = 0;
    char *check = "abcdefABCDEF0123456789";
    for(int i=0;*(line+i) != '\0';i++){
        if(isBlank(*(line+i)) == 1){
            break;
        }else{
            int isValid = 0;
            for(int e=0;e<22;e++){
                if(*(check+e) == *(line+i)){
                    isValid = 1;
                    counter++;
                    break;
                }
            }
            if(isValid == 0){
                return -1;
            }
        }
        if(i > 7){
            return -1;
        }
    }
    return counter;
}
uint32_t charToHex(char * str){
    uint32_t hex = 0;
    int size = stringLength(str);
    for(int i=0;i<size;i++){
        uint8_t hexVal = 0;
        switch (*(str+i)){
            case '0':
                hexVal = 0;
                break;
            case '1':
                hexVal = 1;
                break;
            case '2':
                hexVal = 2;
                break;
            case '3':
                hexVal = 3;
                break;
            case '4':
                hexVal = 4;
                break;
            case '5':
                hexVal = 5;
                break;
            case '6':
                hexVal = 6;
                break;
            case '7':
                hexVal = 7;
                break;
            case '8':
                hexVal = 8;
                break;
            case '9':
                hexVal = 9;
                break;
            case 'A':
            case 'a':
                hexVal = 10;
                break;
            case 'B':
            case 'b':
                hexVal = 11;
                break;
            case 'C':
            case 'c':
                hexVal = 12;
                break;
            case 'D':
            case 'd':
                hexVal = 13;
                break;
            case 'E':
            case 'e':
                hexVal = 14;
                break;
            case 'F':
            case 'f':
                hexVal = 15;
                break;
            default:
                return 0;
        }
        hex = (hex * 16) + hexVal;
    }
    return hex;
}

int verifyMneumonic(char * str){
    char * check = "abcdefghijklmnopqrstuvwxyz";
    int counter = 0;
    for(int i=0;*(str+i) != '\0';i++){
        if(isBlank(*(str+i)) == 1){
            break;
        }
        int isValid = 0;
        for(int e = 0;e<26;e++){
            if(*(str+i) == *(check+e)){
                isValid = 1;
                break;
            }
        }
        if(isValid == 0){
            return -1;
        }
        counter++;       
    }
    return counter;
}
int verifyPetty(char * str){
    char * digits = "0123456789";
    int counter = 0;
    for(int i=0;*(str+i) != '\0';i++){
        if(isBlank(*(str+i)) == 1){
            break;
        }
        int isValid = 0;
        int allowedNum = 1;
        for(int e=0;e<10;e++){
            if(*(str+i) == *(digits+e)){
                if(*(digits+e) == '1'){
                    allowedNum = 2;
                    if(isBlank(*(str+i+1)) == 0){
                        counter++;
                        i++;
                        if(*(str+i) != '0'){
                            break;
                        }
                    }
                }
                if(i < allowedNum){
                    isValid = 1;
                }
                break;
            }
        }
        if(isValid == 0){
            return -1;
        }
        counter++;
    }
    return counter;
}
uint8_t strint8(char* str) {
    uint8_t theInt = 0;
    int i=0;
    for (; *(str+i) != '\0'; i++) {
        char c = *(str+i);
        theInt = (theInt * 10) + (c - '0');
    }
    *(str+i) = '\0';
    return theInt;
}
